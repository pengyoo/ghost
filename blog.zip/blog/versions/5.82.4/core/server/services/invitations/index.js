module.exports = {
    get accept() {
        return require('./accept');
    }
};
