const EmailAnalyticsServiceWrapper = require('./EmailAnalyticsServiceWrapper');

module.exports = new EmailAnalyticsServiceWrapper();
