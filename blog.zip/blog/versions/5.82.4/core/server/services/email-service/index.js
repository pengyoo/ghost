const EmailServiceWrapper = require('./EmailServiceWrapper');

module.exports = new EmailServiceWrapper();
