const EmailAddressServiceWrapper = require('./EmailAddressServiceWrapper');

module.exports = new EmailAddressServiceWrapper();
