const DonationServiceWrapper = require('./DonationServiceWrapper');

module.exports = new DonationServiceWrapper();
