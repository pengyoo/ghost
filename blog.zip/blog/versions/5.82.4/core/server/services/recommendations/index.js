const RecommendationServiceWrapper = require('./RecommendationServiceWrapper');

module.exports = new RecommendationServiceWrapper();
