module.exports = {
    counts(response, apiConfig, frame) {
        frame.response = response;
    }
};
