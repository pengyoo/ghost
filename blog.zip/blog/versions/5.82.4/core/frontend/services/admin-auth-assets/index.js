const AdminAuthAssetsService = require('./AdminAuthAssetsService');
let adminAuthAssets = new AdminAuthAssetsService();

module.exports = adminAuthAssets;
