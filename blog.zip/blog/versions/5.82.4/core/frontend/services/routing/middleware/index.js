module.exports = {
    get pageParam() {
        return require('./page-param');
    }
};
